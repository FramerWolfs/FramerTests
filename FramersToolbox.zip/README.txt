Framer's Toolbox Website

Open 'index.html' in your browser to view the website.
Add your downloadable tools inside the 'downloads' folder and link them in the HTML.
